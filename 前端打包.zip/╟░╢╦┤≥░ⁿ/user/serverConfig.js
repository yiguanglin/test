(function (window) {
  window.$config = {
    BASE_API: "http://18.162.46.20:888/user/", //  USER的 IP地址
  };
})(window);
