(function (window) {
  window.$config = {
    BASE_API: "http://18.163.33.64:888/admin", // admin的 IP地址
  };
})(window);
