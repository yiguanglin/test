# 创建一个映射对象
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()