module.exports = {
  // 解决打包组件的报错问题
  lintOnSave: false,

  css: {
    modules: true,
    // 解决elementui样式不生效问题
    requireModuleExtension: true
  }

}
